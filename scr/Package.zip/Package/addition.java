package Package;

public class addition {
    public int add(int a, int b) {
        return a + b;
    }
}
